export default function ReviewMainPage() {
  return null;
}
