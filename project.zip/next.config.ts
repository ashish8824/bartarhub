/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["utkctcdndvlqlavdpkif.supabase.co"],
  },
};

module.exports = nextConfig;
